## Express REST API with LowDB

### Installation

npm i
npm start

#### Issues
* https://stackoverflow.com/questions/66508616/require-of-es-modules-is-not-supported-error-with-node-js-express-swagge
* https://github.com/Surnet/swagger-jsdoc/issues/249